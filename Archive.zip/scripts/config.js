angular.module('dumboApp.config', [])
.constant('EnvironmentConfig', {"api":"http://localhost","production":false});
